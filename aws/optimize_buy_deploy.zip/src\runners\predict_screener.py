"""Packaged CLI wrapper for the prediction screener.

This mirrors the existing `tools/predict_screener_cli.py` but lives inside
the installed package so console-scripts can import it reliably.
"""

from __future__ import annotations

import argparse
from contextlib import contextmanager
import json
import os
import sys
from datetime import datetime
from pathlib import Path
from typing import Any

import pandas as pd
from alpaca.trading.client import TradingClient

# Ensure the repo root is accessible for imports
REPO_ROOT = Path(__file__).resolve().parents[2]
SRC_ROOT = REPO_ROOT / "src"

# Prioritize src/ directory over installed package
if str(SRC_ROOT) not in sys.path:
    sys.path.insert(0, str(SRC_ROOT))

from fin_trade_alpaca.env_loader import load_environment_for_mode
from yfinance.screener.predict_short_term import (
    build_dataset,
    find_latest_screener_file,
    train_and_evaluate,
)

DEFAULT_PREDICTION_CONFIG: dict[str, Any] = {
    "candidates_file": None,
    "sector": None,
    "industry": None,
    "limit": 200,
    "return_days": 5,
    "lookback": 180,
    "out": None,
    "versioned": False,
    "include_short_term_positions": True,
    "download_batch_size": 25,
    "download_batch_pause": 2.0,
    "download_max_retries": 2,
    "download_retry_pause": 5.0,
    "model": {
        "type": "lightgbm",
        "n_estimators": 200,
        "learning_rate": 0.05,
        "random_state": 42,
        "tune": False,
        "tune_n_iter": 6,
        "tune_cv": 3,
    },
    "target": {"horizon_days": 5, "label_column": "fwd_ret"},
}

_YFINANCE_ENV_KEYS = {
    "download_batch_size": "YFINANCE_DOWNLOAD_BATCH_SIZE",
    "download_batch_pause": "YFINANCE_DOWNLOAD_BATCH_PAUSE",
    "download_max_retries": "YFINANCE_DOWNLOAD_MAX_RETRIES",
    "download_retry_pause": "YFINANCE_DOWNLOAD_RETRY_PAUSE",
}


def resolve_credentials(mode: str) -> tuple[str | None, str | None, str | None, bool]:
    """Resolve Alpaca credentials for the given mode (paper or live).

    Returns: (api_key, api_secret, oauth_token, paper)
    """
    if mode == "paper":
        oauth_token = os.getenv("ALPACA_PAPER_OAUTH_TOKEN") or os.getenv("ALPACA_OAUTH_TOKEN")
        api_key = os.getenv("ALPACA_PAPER_API_KEY") or os.getenv("ALPACA_API_KEY")
        api_secret = os.getenv("ALPACA_PAPER_API_SECRET") or os.getenv("ALPACA_API_SECRET")
        paper = True
    else:
        oauth_token = os.getenv("ALPACA_LIVE_OAUTH_TOKEN") or os.getenv("ALPACA_OAUTH_TOKEN")
        api_key = os.getenv("ALPACA_LIVE_API_KEY") or os.getenv("ALPACA_INDIVIDUAL_API_KEY")
        api_secret = os.getenv("ALPACA_LIVE_API_SECRET") or os.getenv("ALPACA_INDIVIDUAL_API_SECRET_KEY")
        paper = False

    return api_key, api_secret, oauth_token, paper


def fetch_short_term_positions() -> set[str]:
    """Fetch current short-term positions from both live and paper accounts.

    Returns a set of symbol strings (uppercase).
    """
    positions: set[str] = set()

    # Save current environment to restore later
    original_env = dict(os.environ)  # Use dict() instead of copy.copy()

    for mode in ["paper", "live"]:
        try:
            # Restore original environment before loading mode-specific env
            os.environ.clear()
            os.environ.update(original_env)

            load_environment_for_mode(mode)
            api_key, api_secret, oauth_token, paper = resolve_credentials(mode)

            if not oauth_token and (not api_key or not api_secret):
                print(f"Skipping {mode} positions: credentials not found")
                continue

            client = TradingClient(
                api_key=api_key,
                secret_key=api_secret,
                oauth_token=oauth_token,
                paper=paper,
            )

            for pos in client.get_all_positions():
                symbol = pos.symbol.strip().upper()
                positions.add(symbol)
                print(f"Found {mode} position: {symbol}")

        except Exception as ex:
            print(f"Warning: Unable to fetch {mode} positions: {ex}")

    # Restore original environment
    os.environ.clear()
    os.environ.update(original_env)

    return positions


def load_prediction_config(config_path: str | Path | None) -> dict[str, Any]:
    """Load the prediction screener JSON config, if present."""
    if not config_path:
        return {}

    path = Path(config_path)
    if not path.exists():
        raise FileNotFoundError(f"Prediction config not found: {path}")

    with path.open("r", encoding="utf-8") as fh:
        data = json.load(fh)

    if not isinstance(data, dict):
        raise ValueError("Prediction config must be a JSON object")

    return data


def resolve_runtime_config(args: argparse.Namespace) -> dict[str, Any]:
    """Merge config-file defaults with CLI overrides."""
    config = load_prediction_config(getattr(args, "config", None))
    merged = dict(DEFAULT_PREDICTION_CONFIG)
    merged.update(config)

    for key, value in vars(args).items():
        if key == "config":
            continue
        if value is not None:
            merged[key] = value

    # normalize keys so CLI option names and config keys line up
    merged["candidates_file"] = merged.get("candidates_file")
    merged["sector"] = merged.get("sector")
    merged["industry"] = merged.get("industry")
    merged["limit"] = int(merged.get("limit", DEFAULT_PREDICTION_CONFIG["limit"]))
    merged["return_days"] = int(merged.get("return_days", DEFAULT_PREDICTION_CONFIG["return_days"]))
    merged["lookback"] = int(merged.get("lookback", DEFAULT_PREDICTION_CONFIG["lookback"]))
    merged["out"] = merged.get("out")
    merged["versioned"] = bool(merged.get("versioned", False))
    merged["download_batch_size"] = int(
        merged.get("download_batch_size", DEFAULT_PREDICTION_CONFIG["download_batch_size"])
    )
    merged["download_batch_pause"] = float(
        merged.get("download_batch_pause", DEFAULT_PREDICTION_CONFIG["download_batch_pause"])
    )
    merged["download_max_retries"] = int(
        merged.get("download_max_retries", DEFAULT_PREDICTION_CONFIG["download_max_retries"])
    )
    merged["download_retry_pause"] = float(
        merged.get("download_retry_pause", DEFAULT_PREDICTION_CONFIG["download_retry_pause"])
    )
    return merged


@contextmanager
def configured_yfinance_downloads(runtime: dict[str, Any]):
    previous: dict[str, str | None] = {}
    try:
        for config_key, env_key in _YFINANCE_ENV_KEYS.items():
            previous[env_key] = os.environ.get(env_key)
            os.environ[env_key] = str(runtime[config_key])
        yield
    finally:
        for env_key, old_value in previous.items():
            if old_value is None:
                os.environ.pop(env_key, None)
            else:
                os.environ[env_key] = old_value


def filter_candidates(df: pd.DataFrame, sector: str | None, industry: str | None) -> pd.DataFrame:
    if sector:
        if "sector" in df.columns:
            df = df[df["sector"].astype(str).str.contains(sector, case=False, na=False)]
        else:
            print("Warning: candidates file has no `sector` column; ignoring --sector")
    if industry:
        if "industry" in df.columns:
            df = df[df["industry"].astype(str).str.contains(industry, case=False, na=False)]
        else:
            print("Warning: candidates file has no `industry` column; ignoring --industry")
    return df


def score_latest_local(
    model,
    feat_cols: list,
    cand_df: pd.DataFrame,
    symbols: list[str],
    return_days: int,
    out_path: Path,
    scaler=None,
    metrics: dict = None,
):
    """Score latest prices using enhanced features from predict_short_term module.

    Args:
        scaler: Fitted StandardScaler from training data (prevents data leakage)
    """
    from yfinance.screener.predict_short_term import score_latest

    # Use the updated score_latest that handles enhanced features
    df = score_latest(
        model, feat_cols, cand_df, symbols, return_days, scaler=scaler, metrics=metrics, use_enhanced_features=True
    )

    if df.empty:
        raise SystemExit("No rows to score")

    # Add avg_ret column if not present
    if "avg_ret" not in df.columns and all(c in df.columns for c in ["ret_1d", "ret_3d", "ret_5d"]):
        df["avg_ret"] = df[["ret_1d", "ret_3d", "ret_5d"]].mean(axis=1)

    # score_latest already handles ranking and column ordering
    out_path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(out_path, index=False)
    print(f"Wrote predictions to {out_path}")


def main():
    p = argparse.ArgumentParser(description="Run prediction screener with filtering options")
    p.add_argument("--config", help="Path to JSON config file for prediction screener settings")
    p.add_argument("--candidates-file", default=None, help="Input screener CSV (if omitted use latest)")
    p.add_argument("--sector", default=None, help="Filter symbols by sector (case-insensitive substring)")
    p.add_argument("--industry", default=None, help="Filter symbols by industry (case-insensitive substring)")
    p.add_argument("--limit", type=int, default=None, help="Max number of symbols to analyze")
    p.add_argument("--return-days", type=int, default=None, choices=[1, 3, 5], help="Forward return horizon to predict")
    p.add_argument("--lookback", type=int, default=None, help="Price history lookback (days)")
    p.add_argument("--out", default=None, help="Optional output path for predictions CSV")
    p.add_argument("--versioned", action="store_const", const=True, default=None, help="Also save a timestamped copy")
    args = p.parse_args()

    runtime = resolve_runtime_config(args)

    repo = Path(__file__).resolve().parents[2]
    reports = repo / "reports" / "screener_results"

    if runtime["candidates_file"]:
        cand_file = Path(runtime["candidates_file"])
    else:
        cand_file = find_latest_screener_file(reports)

    print(f"Using candidates file: {cand_file}")
    cand_df = pd.read_csv(cand_file)
    cand_df = filter_candidates(cand_df, runtime["sector"], runtime["industry"])

    # Always include current short-term positions from both accounts
    short_term_positions: set[str] = set()
    if runtime.get("include_short_term_positions", True):
        short_term_positions = fetch_short_term_positions()
        if short_term_positions:
            print(
                f"Found {len(short_term_positions)} short-term positions to include: {', '.join(sorted(short_term_positions))}"
            )

    # Select symbols from filtered candidates (up to limit)
    candidate_symbols = list(cand_df["symbol"].astype(str).str.upper().unique())

    # Ensure short-term positions are always included
    symbols_from_screener = [s for s in candidate_symbols if s not in short_term_positions][: runtime["limit"]]

    # Combine: positions + screener symbols (incremental count)
    symbols = sorted(short_term_positions) + symbols_from_screener

    print(
        f"Analyzing {len(symbols)} symbols: {len(short_term_positions)} positions + {len(symbols_from_screener)} from screener (limit={runtime['limit']})"
    )

    # Try to build dataset with adaptive lookback fallback
    df = pd.DataFrame()
    lookback_attempts = [runtime["lookback"], 180, 90, 60]

    with configured_yfinance_downloads(runtime):
        for attempt, lookback in enumerate(lookback_attempts):
            if attempt > 0:
                print(f"\nRetrying with shorter lookback: {lookback} days...")

            df = build_dataset(cand_df, symbols, lookback, runtime["return_days"])

            if not df.empty:
                if attempt > 0:
                    print(f"[OK] Successfully built dataset with {lookback}-day lookback")
                break

            if attempt < len(lookback_attempts) - 1:
                print(f"[RETRY] Failed with {lookback}-day lookback, trying shorter period...")

    if df.empty:
        print("\n" + "=" * 60)
        print("ERROR: Unable to construct training data")
        print("=" * 60)
        print("\nPossible causes:")
        print("  1. Symbols may be newly listed with insufficient history")
        print("  2. yfinance download may have failed (check connectivity)")
        print("  3. Date range may be too far in the future")
        print("\nSuggestions:")
        print("  - Check if symbols in screener CSV have valid price history")
        print("  - Try running with fewer symbols (--limit 50)")
        print(
            '  - Verify yfinance is working: python -c \'import yfinance; print(yfinance.Ticker("AAPL").history(period="1mo"))\''
        )
        print("=" * 60)
        raise SystemExit(1)

    print(f"Constructed dataset with {len(df)} rows")
    model, feat_cols, metrics, feature_importance, scaler = train_and_evaluate(
        df,
        runtime["return_days"],
        model_config=runtime.get("model", {}),
    )

    # determine output path
    ts = datetime.utcnow().strftime("%Y%m%d")
    if runtime["out"]:
        out_path = Path(runtime["out"])
    else:
        out_path = reports / f"predictions_{ts}.csv"
    if not feature_importance.empty:
        # Use same directory as output path for feature importance
        fi_path = out_path.parent / f"feature_importance_{ts}.csv"
        fi_path.parent.mkdir(parents=True, exist_ok=True)
        feature_importance.to_csv(fi_path, index=False)
        print(f"Wrote feature importances to {fi_path}")

    with configured_yfinance_downloads(runtime):
        score_latest_local(
            model, feat_cols, cand_df, symbols, runtime["return_days"], out_path, scaler=scaler, metrics=metrics
        )

    if runtime["versioned"]:
        ver = datetime.utcnow().strftime("%Y%m%dT%H%M%S")
        ver_path = out_path.with_name(out_path.stem + f".v{ver}" + out_path.suffix)
        ver_path.parent.mkdir(parents=True, exist_ok=True)
        ver_path.write_text(out_path.read_text())
        print(f"Wrote versioned copy: {ver_path}")


if __name__ == "__main__":
    main()
